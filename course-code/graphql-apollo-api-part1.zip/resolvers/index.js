const userResolver = require('./user');
const taskResolver = require('./task');

module.exports = [
  userResolver,
  taskResolver
];
# get into project folder

cd graphql-apollo-api-part1

# install dependencies

 npm install

# Run local dev server

npm run dev


